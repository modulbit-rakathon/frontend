# PillGaze core 0.6.1 — předání Jonášovi a Vítkovi

Tento projekt obsahuje **jen core**. Frontend patří Jonášovi, backend Vítkovi.
Jejich repozitáře se tady neupravují. Knihovna neprovádí HTTP volání a nepotřebuje
API klíč ani běžící model.

## Skutečný kontrakt backendu

Podle [API v2](https://github.com/modulbit-rakathon/backend/blob/c13149d17ea4480eedd37addc3a2a3a8fafa33e9/docs/api.md).
Nasazená základní URL je `https://pillgaze-team92.azurewebsites.net`;
lokálně příklad vypadá takto:

```bash
curl -s \
  -H "X-Api-Key: $APP_API_KEY" \
  -F source=box \
  -F image=@./testovaci-fotka.jpg \
  http://localhost:8080/api/analyze
```

- Metoda/cesta: `POST /api/analyze`.
- Multipart: opakované `image`, max 6 JPEG/PNG souborů, dohromady 10 MiB;
  `source` je `box`, `note` nebo `regimen`.
- Hlavička: `X-Api-Key`, spravuje transport/backend, nikoli core.
- Odpověď: `{ medications: [...], unreadable_items: 0 }`; `unreadable_items` je počet.
- Lék: `id`, `kind`, `name`, `active_substance`, `strength`, `form`, `frequency`,
  `amount`, `source`, volitelné `note_style` (`printed` / `handwritten`),
  `uncertain_fields`, volitelné `sources` a `conflicts`.
- `uncertain_fields` dovoluje všech šest textových polí, včetně `form` a `active_substance`.
- Upload `source=regimen` vrátí položky `kind=regimen`, `source=note`.
- Chyby mají tvar `{ "error": { "code": "...", "message": "..." } }`.
- `/api/share` a `/api/share/claim` mají vlastní užší `SharedMedication`; neposílat
  do nich celé výsledky core. V Go kódu už oba endpointy existují.

Klíč necommitujte a nevkládejte do veřejného frontendového bundlu ani `VITE_` proměnných.
Způsob bezpečného připojení a případnou serverovou proxy si domluví Jonáš s Vítkem.
Core neřeší URL, CORS, autentizaci ani odesílání fotografie.

## Co adaptér dělá

`mapBackendResponse` mění číselné `unreadable_items` na pole čitelných zpráv:

| Vstup | Výstup pro UI |
| --- | --- |
| `unreadable_items: 0` | `unreadable_items: []`, `unreadable_count: 0` |
| `unreadable_items: 2` | jedna zpráva s počtem 2, `unreadable_count: 2` |
| `unreadable_items: ["nečitelný řádek"]` | zachová zprávy a doplní `unreadable_count: 1`, pokud není dodaný počet |

Počet není text konkrétního nepřečteného řádku; adaptér si názvy nepřečtených léků
nevymýšlí. Prázdný výsledek může mít nenulový počet nepřečtených položek.
Nesprávné typy nebo záporné počty vyvolají `TypeError`.

`prepareAnalysisResult` přidá kandidáty a nejistoty. Všechna v2 pole jsou také top-level,
včetně původního `id` a `kind`. V `_core.original` uchová původní metadata a `null`;
lokální `_core.observationId` identifikuje konkrétní pozorování. `uncertain_fields` z backendu
uchovává zvlášť v `_core.originalUncertainFields`.
`Advagraf 3 mg` se silou `3 mg` se páruje s `ADVAGRAF` v katalogu; odvozená varianta
názvu je jen vyhledávací klíč. Původní OCR se nepřepisuje a jiná síla se nezamlčí.

Obecné pokyny z krabičky nejsou pacientovo potvrzené dávkování: u `source: "box"`
jsou `frequency` i `amount` k ověření i tehdy, když je OCR přečetlo bez nejistoty.
U všech zdrojů zůstávají chybějící pole neznámá, nenahrazují se obvyklými dávkami.

Tištěný a ručně psaný řádek stejného léku zůstanou **dvě položky**. Core je
automaticky neslučuje ani nepotlačuje různé síly. `note_style` se neztrácí.
Pro potvrzené seskupení už ve verzi 0.6 slouží `mergeMedications` přímo nad v2
položkami: váhy převede podle note_style, neznámý styl neodhadne. Starší
`mergeMedicationEvidence` zůstává pro vlastní interní `values` formát.

## Jonáš — použití knihovny

Hotový balíček je ke stažení v soukromém [vydání v0.6.1](https://github.com/modulbit-rakathon/core/releases/tag/v0.6.1).
Vlastní vytvoření balíčku ze zdrojů:

```bash
# v core/
npm test
npm pack
# výsledný pillgaze-core-0.6.1.tgz předat Jonášovi
```

Jonáš jej může stáhnout ve svém frontendu (vyžaduje přístup do soukromého repozitáře):

```bash
mkdir -p vendor
gh release download v0.6.1 --repo modulbit-rakathon/core --pattern pillgaze-core-0.6.1.tgz --dir vendor
npm install ./vendor/pillgaze-core-0.6.1.tgz
```

Archiv i lockfile pak musí být ve frontendu verzované. Tyto změny jsou na něm,
zde se neprovádějí.

Integrace s jeho HTTP klientem (`rawAnalyzePhoto` níže znamená funkci, kterou dodá on):

```js
import { createAnalyzePhoto, finalizeMedication } from '@pillgaze/core';
import catalog from '@pillgaze/core/catalog';

const analyzePhoto = createAnalyzePhoto({
  analyze: rawAnalyzePhoto,
  catalog,
});

// Aktuální frontend/api.js přijímá (file, source), ne objekt options:
const result = await analyzePhoto(file, 'box');
// createAnalyzePhoto převádí skutečnou odpověď API automaticky.
if (result.medications.length > 0) {
  const current = result.medications[0];
  // Spustit až při pacientově uložení formuláře:
  const saved = finalizeMedication(current, formValues, {
    catalog,
    confirmedFields: ['amount'], // jen pole výslovně zkontrolované pacientem
  });
  addMed(saved); // uložit celý objekt, ne pouze textová pole
}
```

Ukázka předpokládá, že klient nejdřív vyřeší chybový HTTP stav a vrátí rozparsovaný JSON.
Výjimky knihovna nepolyká; obslouží je UI. Prázdný `result.medications` se nesmí indexovat,
UI má místo toho zobrazit `unreadable_items` a nabídnout ruční zadání.
`confirmedFields` není automaticky všechno při kliknutí „Přidat“. Chybějící hodnota,
neznámý název či nejednoznačná síla zůstávají k ověření i po potvrzení.

Pokud se odpověď zpracovává přímo bez wrapperu:

```js
import { prepareAnalysisResult, prepareMedications } from '@pillgaze/core';
const result = prepareAnalysisResult(rawJson, {
  catalog,
  analysisId: 'unikatni-id-fotky',
});
// Alternativa, pokud aplikace samostatně uchová rawJson.unreadable_items:
const meds = prepareMedications(rawJson.medications, {
  catalog,
  analysisId: 'jine-unikatni-id-fotky',
});
```

Výchozí wrapper používá `crypto.randomUUID()` (HTTPS/localhost). Pro LAN HTTP klient
může dodat vlastní `createAnalysisId`; jde jen o identifikátor pozorování, nikdy PIN
nebo přístupový token.

### Konkrétní změny potřebné ve frontendu

[Issue #2](https://github.com/modulbit-rakathon/core/issues/2) je o napojení,
[issue #3](https://github.com/modulbit-rakathon/core/issues/3) o hledání ve formuláři.
Kontrola kódu frontendu `a19a49e` ukázala tyto integrační podmínky:

- Wrapper předejte existujícímu `api.js`; core nemění HTTP ani autentizaci.
  Zrušení přes signal funguje jen tehdy, pokud jej podporuje i HTTP klient;
  současný klient má vlastní timeout, ne externí signal.
- UI nyní porovnává `unreadable > 0`. Po core použijte `result.unreadable_count`,
  texty jsou v `result.unreadable_items`. Počet držte i po přechodu ze Scan do seznamu;
  nevynulovat ho při uložení jiného čitelného léku.
- `Scan.handleConfirm` musí místo `{ ...values, source }` uložit celý výsledek
  `finalizeMedication`. Současný lossy zápis zahazuje metadata a další v2 pole.
- `MedsContext.addMed` může přidělit unikátní lokální ID, ale musí zachovat celý
  zbytek objektu. Backend může opakovat ID mezi fotkami; původní ID zůstává v original.
- `MedForm` inicializuje useState pouze jednou. Po výběru kandidáta je nutné změnit
  i formulářový stav nebo formulář cíleně znovu vytvořit; samotná změna initial nestačí.
  Zachovejte rozpracované úpravy a neprovádějte remount při každém stisku klávesy.
- Čtyři dnešní pole nemají UI pro látku/formu ani explicitní potvrzení všech nejistot.
  Doplnit jejich zobrazení, původ a potvrzení. Nezaškrtnout vše automaticky.
- Po změně názvu/síly/formy znovu potvrdit neprázdné údaje včetně dávkování.
  Uložené 0.6 objekty bez reviewedProvenance vyžadují novou kontrolu.
- `Pin` nyní používá mock. Před skutečným share vyhodnotit `getShareIssues`
  s přetrvávajícím počtem nepřečtených řádků a poslat pouze `createSharePayload`.

Pro ruční psaní názvu použijte rychlé prefixové hledání, pro OCR překlep fuzzy návrhy:

```js
import { searchMedicationCandidates } from '@pillgaze/core';

// V async inicializaci hledání; katalog nenačítat ani neparsovat při každém písmenu.
const { default: catalog } = await import('@pillgaze/core/sukl-catalog');
const query = typedName.trim();
const choices = query.length >= 2
  ? searchMedicationCandidates(query, catalog, { limit: 10 })
  : null;
```

V UI má smysl debounce přibližně 200 ms. Ukažte název, sílu, formu a zdroj;
stejný název se může objevit vícekrát s jinou formou nebo registrací.
`not_found` znamená žádný návrh, nikoli potvrzení neexistence léku.
Chybu načítání katalogu zobrazte jako chybu, ne jako prázdné úspěšné hledání.
Kandidáty lze vybrat i z `_core.match.candidates`, když je přesná shoda;
`_core.suggestions` v takovém případě může být null. Výběr může doplnit látku i tehdy.

UI musí zobrazit kandidáty, `uncertain_fields`, původ dat a původní údaje také v seznamu
a lékařské zprávě. Samotné uložení metadat bez jejich zobrazení není hotová integrace.
Pokud formulář zahodí `_core`, ztratí se historie i původní metadata backendu.
Pouhé čtyři předané hodnoty v `finalizeMedication` jsou v pořádku: ostatní v2 pole
se zachovají. `addMed({ ...values, source })` ale pořád nestačí. Také ruční zadání
nejprve připravte přes `prepareMedications([{ ...values, source: 'manual' }], options)`
a potvrďte přes finalize. Staré uložené objekty 0.4 znovu zkontrolujte přes finalize.

### Překlepy, doplnění látky a potvrzené sloučení

Výsledný záznam neměňte přímo. UI může ukázat `current._core.suggestions.suggestions`
(kandidát, důvod, vzdálenost a souhlas síly), původní OCR a dostupné varianty.
Pro ručně napsaný dotaz lze také volat `suggestMedicationCandidates`.
Nejlepší návrh není automaticky správný lék. Silně nečitelný název může vyžadovat
novou fotografii nebo ruční vyhledání, nikoli vynucený fuzzy výsledek.

```js
import {
  selectMedicationCandidate, suggestMedicationGroups, mergeMedications,
} from '@pillgaze/core';

// Pouze po výslovném výběru konkrétní varianty pacientem:
const selected = selectMedicationCandidate(current, chosenCandidateId, { catalog });
// selected obsahuje návrh látky/formy, původ a historii. Ještě není schválený.
// Zobrazit do formuláře, potom finalizeMedication s pouze ověřenými confirmedFields.

const proposals = suggestMedicationGroups(result.medications, { catalog });
// Zobrazit oba původní řádky; dotázat se, zda je to tentýž užívaný lék.
// Následující blok spustit až po výslovném potvrzení konkrétní skupiny:
const observations = result.medications.filter(med =>
  chosenProposal.observationIds.includes(med._core.observationId));
const merged = mergeMedications(observations, {
  catalog, mergedId: crypto.randomUUID(), groupConfirmed: true,
});
// Ukázat merged.conflicts a merged._core.merge.fields, vyřešit hodnoty ve formuláři.
// finalizeMedication(merged, patientValues, { catalog, confirmedFields: checkedFields })
// Až potom nahradit vstupní řádky celým uloženým merged objektem.
```

`chosenCandidateId`, `chosenProposal`, `patientValues` a `checkedFields` dodá UI po
skutečné kontrole. Nevytvářejte `checkedFields` automaticky ze všech šesti polí.
U shodného léčiva z více fotografií používejte unikátní `analysisId` pro každou analýzu
a vybírejte skupinu přes `observationIds`, ne jen případně opakované backendové `id`.
Automatické návrhy skupin jsou záměrně jen pro sousední poznámkové řádky; ručně
potvrzená skupina pro merge může obsahovat i pozorování z různých fotografií.
Potvrzení skupiny **neřeší hodnotové konflikty**. Výběr katalogu také není potvrzení
všech polí; teprve finalize a následný export kontrolují aktuální hodnoty.

Látka se přebírá doslova z `ingredientText`, nikoli z odhadu LLM.
Původní OCR je dostupné v `_core.original`, po sloučení ve
`_core.evidence[*]._core.original` u připravených vstupů; u raw vstupů přímo v evidence.
Prázdná katalogová forma se neodvozuje z názvu balení. Změna názvu/síly/formy
zneplatní dřívější odvozené katalogové údaje, pokud je pacient výslovně nepotvrdí.
SÚKL může vrátit látky delší než share limit 100 znaků: nezkracovat je automaticky,
řešit hlášený limit v UI a případnou potřebu širšího kontraktu s Vítkem.
Stejná látka není povolení k výměně značky, dávky nebo lékové formy.

### Příprava skutečného PIN sdílení

```js
import { getShareIssues, createSharePayload } from '@pillgaze/core';

// Zbylé nepřečtené položky ze všech analýz; 0 teprve po jejich ručním doplnění.
const options = { unreadableCount: remainingUnreadableCount };
const issues = getShareIssues(savedMeds, options);
if (issues.length > 0) {
  showShareIssues(issues); // UI zobrazí problém, nic se neodešle
} else {
  const body = createSharePayload(savedMeds, options);
  const { pin, expires_at, expires_in } = await rawShare(body);
  // rawShare dodává HTTP klient: POST /api/share, JSON body a X-Api-Key.
  showPin(pin, expires_at, expires_in);
}
```

Chybějící nepovinné údaje se odešlou jako `null`, nikoli odhady. U neprázdných
nejistých polí je nutné výslovné `confirmedFields`; kliknutí na „Uložit“ samotné
je nevyřeší. Při konfliktu musí pacient vybrat/opravit hodnotu a potvrdit dané
pole ve finalize; alternativy a aktér zůstanou lokálně v historii.
Pokud rozpor nejde ověřit, pacient nesmí hádat. V2 jeho nevyřešené alternativy
lékaři předat neumí; jejich přenos vyžaduje domluvené rozšíření kontraktu.
Jestliže se po kontrole záznam změní mimo finalize, export vyžaduje kontrolu znovu.
Neodesílat `JSON.stringify(savedMeds)` ani `{ medications: savedMeds }`.
Core nekrátí dlouhé texty; `issues` ukáže mimo jiné limit 100 znaků a duplicity ID.
Kódy jsou stabilní programové hodnoty, zprávy v angličtině jsou pro diagnostiku;
české znění si UI mapuje podle `code` a `field`.

PIN držte jako string (`"0482"`, ne číslo). Platí 180 sekund a claim jej spotřebuje.
Lékařský klient volá `POST /api/share/claim` s `{ pin }` a stejnou autentizací;
vrácený `SharedMedication[]` už nemá `_core`, nejistoty ani konflikty. `404` znamená
neexistující nebo prošlý PIN, `429` respektovat s `Retry-After`.
Testovací `0000` vrací opakovatelný vzor pouze při backendovém `MOCK_AI=true`.
Interakce a rozklad režimů nejsou součást v2 a nemají se zobrazovat pacientovi.

### Volitelný širší katalog SÚKL

Původní import `@pillgaze/core/catalog` stále vrací 303 položek ze zadání. Pro 21 226
oficiálních variant včetně Ibalginu zvolte **výslovně jiný import**:

```js
import catalog from '@pillgaze/core/sukl-catalog';
import metadata from '@pillgaze/core/sukl-metadata';
import { searchMedicationCandidates } from '@pillgaze/core';

const suggestions = searchMedicationCandidates('Ibalgin', catalog, { limit: 20 });
// candidates obsahuje varianty, total celkový počet, truncated označuje zkrácení.
```

Tento stejný `catalog` předejte jak do `createAnalyzePhoto`, tak do `finalizeMedication`.
Nemíchejte při analýze a uložení různé katalogy. Backendový JSON ani multipart se nemění.
Návrhy jsou vždy `needs_review`, i kdyby byl jediný; prázdný výsledek je `not_found`.
`matchMedication` nad tímto katalogem dál vrací původní tři stavy podle názvu a síly.

Ukažte `name`, `strength`, `form`, `route` a podle potřeby `packages` i skutečné kódy SÚKL.
Krém a gel stejné síly mohou zůstat dvěma kandidáty; nezaškrtávejte je automaticky jako
vyřešené. Stávající čtyřpolový formulář formu ještě neřeší. Knihovna nedoplňuje UX výběru
do Jonášova repozitáře a netvrdí, že výběr varianty identifikuje konkrétní balení.
Před přidáním do seznamu musí výběr ověřit uživatel; lékařská kontrola je další krok.

V UI musí být uvedeno **Zdroj: SÚKL**, období platnosti z `metadata` a odkaz na
`metadata.termsUrl`. Data jsou snapshot na říjen 2026, ne živé API nebo skladové zásoby.
Po `validTo` označte stáří dat a naplánujte aktualizaci. Podrobnosti importu, rozsahu
a podmínek užití jsou v README. Vyhledávání je čistě lokální a neposílá seznam léků
externí službě. SÚKL aplikaci neschvaluje ani nepodporuje.

## Vítek — kompatibilita a ověření

Dodané API není potřeba měnit kvůli internímu core formátu. Současný Go backend
JavaScript přímo neimportuje; tento balíček může používat frontend nad odpovědí API.
Zachovejte původní text, `null`, `source`, `note_style` a nejistoty, neposílejte odhadnuté
pacientské dávkování. Při změně JSONu přidejte vzor a domluvte změnu adaptéru.

```bash
cd core
npm test
npm run demo:backend
npm run demo:v2
npm run demo:issue1
npm run verify:package
```

`fixtures/backend-box.json` odpovídá tvaru ukázky Advagrafu s anonymním vzorovým ID.
`fixtures/backend-note.json` je zkrácený vzor tištěného a ručně psaného seznamu,
navíc s počtem 2 pro ukázku nepřečtených položek. Nejde o nově provedené OCR.
`fixtures/backend-v2.json` přidává zkrácené v2 příklady box/note/regimen a všechny typy
údajů; nejistoty form/látka jsou záměrně přidané pro regresi. Nejde o živé OCR.
`fixtures/issue-1-ocr.json` je syntetická sada pro překlepy, alternativy, samostatný
řádek s látkou, chybějící jednotku a regimen; `demo:issue1` ukazuje celý kontrolovaný tok.
Testy pokrývají převod, původní metadata, nejistoty, historii, blokování sdílení
a přesnou výstupní allowlist. Neověřují medicínskou správnost ani OCR model.
Součást předání 0.6 je kontrola skutečného zabaleného modulu nad Go mock analyze JSONy
a proti Go Share/Claim handlerům v izolované kopii backendu `c13149d`.
Prošlo 83 JavaScript testů, 6 Python testů importerů a původní Go share sada.
Devět dodatečných wire případů zahrnuje box/note/regimen JSONy z backendu,
potvrzený překlep, sloučenou alternativu, box + note, výběr SÚKL,
50 položek se 100 Unicode znaky a maximálně escapované řetězce.
Přenos zachoval hodnoty, PIN `"0482"`, dobu 180 sekund a jednorázový claim.
Jde o kompatibilitu dat a lokálních handlerů, nikoli ověření medicínské správnosti
nebo nasazeného spojení frontend–backend. Produkční klíč ani živé analyze/share se nepoužívají.
Verze 0.6.1 navíc obsahuje 12 integračních regresí (celkem 95 JS testů), včetně
100 deterministických variant serializace a změn všech šesti polí.
`npm run verify:package` nezávisle ověří 12 scénářů ze skutečného tarballu:
vyhledání Ibalginu, návrh pro WAREARiN, katalogový výběr, blokaci bez kontroly,
čtyřpolový formulář, JSON storage, striktní share, ztrátu metadat, změnu identity
a nepřečtené řádky. Používá plný SÚKL katalog, nevytváří skutečný PIN ani nevolá AI.
Automatické potvrzení všech polí v tomto syntetickém důkazu se nesmí kopírovat do UI.
Nad skutečným tarballem byl také sestaven izolovaný Vite 5.4.11 / React 18 spotřebitel
se skutečným `MedForm.jsx` z frontendu: v prohlížeči prošla změna hodnoty, odeslání
čtyř polí, obnova z localStorage, uchování látky/formy/originálu a striktní share JSON.
Nešlo o změnu ani kompletní spuštění produkčního frontendu; potvrzení byla simulovaná
jen pro známá syntetická data.

Naměřený prefix Ibalgin trval přibližně 11 ms, příprava OCR návrhů 49 ms v aktuálním
desktopovém prohlížeči. Není to záruka výkonu na mobilu. SÚKL vytvořil samostatný
lazy chunk přibližně 11 MB / 1,13 MB gzip, nikoli malý vstupní bundle.
Na nasazení ověřte gzip/Brotli a načítejte katalog až pro hledání; při pomalém načítání
zobrazit stav/chybu. Katalog neparsovat při každém písmenu. Základní katalog 303 položek
zůstává možností pro malé demo, ale neobsahuje všechny varianty SÚKL.
Samotný core neumí zapnout mockem nahrazený frontendový transport nebo vytvořit
lékařské UI; známé mezery vůči zadání a konkrétní revize jsou v README.
