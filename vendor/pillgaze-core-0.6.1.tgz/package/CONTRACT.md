# Datová dohoda core 0.6.1 a API v2

## Kompatibilita se současným frontendem

Core podporuje backendový JSON `{ medications, unreadable_items: 0 }`
i původní frontendové `{ medications, unreadable_items: [] }`.
`mapBackendResponse` převádí počet nepřečtených položek na zprávy pro UI a zachová
přesný počet v `unreadable_count`. `createAnalyzePhoto` tento převod používá automaticky;
u legacy pole zpráv bez počtu doplní počet zpráv (ne ověřený počet OCR řádků).
Zprávy s výslovným počtem nula jsou rozporný vstup a vyvolají chybu.
pro přímé použití stačí `prepareAnalysisResult(response, options)`.
Neplatný počet (záporný, desetinný, řetězec, null) vyvolá chybu, nikoli prázdný seznam.
Podrobnosti v [INTEGRATION.md](INTEGRATION.md).

Core vrací top-level `id`, `kind`, všech šest textových polí
`name`, `active_substance`, `strength`, `form`, `frequency`, `amount`,
`source`, `sources`, `conflicts` a dodané `note_style`.
`MEDICATION_FIELDS` obsahuje právě těchto šest upravitelných textových polí a zároveň
všechny dovolené hodnoty v `uncertain_fields`/`confirmedFields`.
V `_core.original` zůstávají původní hodnoty včetně `null` a dodaná v2 metadata;
při uložení je formulář nesmí zahodit.
`_core.originalUncertainFields` zachovává původní `uncertain_fields` backendu, zatímco
výsledné `uncertain_fields` doplňuje také chybějící údaje a problémy katalogu.
Prázdná hodnota je ve formuláři `''`, není to potvrzený údaj.

Pokyny `frequency` a `amount` na krabičce jsou vždy označené k ověření; nejde automaticky
o pacientovo dávkování. Výslovné potvrzení konkrétního neprázdného pole přes
`confirmedFields` je pouze pacientská kontrola, nikoli kontrola lékařem.
Tištěné a ručně psané řádky se stejným názvem se automaticky neslučují:
`note_style` i původní ID zůstávají dohledatelné v samostatných pozorováních.

`prepareMedications(medications, { catalog, analysisId })` přijímá přímo v2 pole
z `analyze` a vrací pole připravených záznamů; počet nepřečtených položek v tomto případě
musí aplikace uchovat zvlášť. Původní mock či ruční záznam bez `id` dostane
`${analysisId}:${index}`, bez `kind` dostane `drug`. Chybné dodané ID či enum se odmítne.
`source: "regimen"` je povolené pouze u uploadu; položka má `kind: "regimen"` a `source: "note"`.
Takový režim se nehledá v katalogu léčiv a nevymýšlí se jeho složení/dávka.

`sources` obsahuje unikátní známé zdroje včetně vlastního `source`. `conflicts` má tvar
`[{ field, values: [{ source, value }] }]`, kde field je jedno ze šesti textových polí.
Jde o import a uchování konfliktů, ne o automatické seskupení fotografií.
U více katalogových variant se zadanou silou je k ověření `form`; párování samo dál
porovnává název a sílu, nikoli klinickou zaměnitelnost nebo vybrané balení.

`finalizeMedication(current, partialValues, { catalog, confirmedFields })` mění jen
poskytnutá textová pole; ostatní zachová. Potvrzení platí jen pro neprázdnou hodnotu,
změna je zruší. Konflikt se odstraní jen při výslovném potvrzení jeho pole v tomto
volání; původní alternativy a rozhodnutí zůstanou v `_core.original.conflicts` a
`_core.resolvedConflicts`. `_core.edits` zachovává změny a aktéra `patient`.
`_core.patientReviewed` znamená pacientskou kontrolu při uložení, ne klinické schválení.
Staré uložené objekty 0.4 lze znovu načíst přes finalize, včetně v2 polí z original;
před novým sdílením se musí znovu zkontrolovat.
Změna názvu, síly či formy ruší všechna dřívější potvrzení včetně dávkování a žádá
novou kontrolu neprázdných polí. Zachovají se jen výslovná potvrzení z téhož volání.
Oprava samotného dávkovacího pole nemění potvrzení nesouvisejících polí.
`_core.reviewedProvenance` zachycuje `sources` a `note_style`; úprava původu mimo
finalize blokuje export stejně jako úprava hodnot. Staré objekty 0.6 bez tohoto
snapshotu vyžadují novou pacientskou kontrolu přes finalize, nikoli automatické schválení.
Výsledky katalogových hledání jsou nezávislé kopie katalogových záznamů.

## OCR návrhy, katalogová volba a v2 slučování

`suggestMedicationCandidates({ name, strength?, kind? }, catalog, { limit = 20 })`
vrací `{ status, reason, candidates, suggestions, total, truncated }`.
Každý návrh má `candidate`, `matchedName`, `reason`, `editDistance`, `strengthMatches`.
Při výsledcích je vždy `needs_review`; vzdálenost není pravděpodobnost.
Porovnávají se i výslovné části názvu v závorkách či za lomítkem. Tyto části
neprokazují, že jde o zaměnitelné léky nebo že je pacient užívá.
Fuzzy hledání připouští nejvýše dvě úpravy, u krátkých názvů méně; chrání názvové
modifikátory RETARD/XR/SR/CR/MR/PROLONG a neodstraňuje je pro shodu s běžnou formou.
Příliš nečitelný název může zůstat `not_found`. Žádný přepis se automaticky nemění.
Adaptér ukládá tyto návrhy do `_core.suggestions`, pokud přímá shoda není `matched`.

Přesná shoda s `uncertain_fields: ["name"]` má `needs_review / uncertain_name`,
ne `matched`. Až výslovné potvrzení názvu ve finalize může tuto OCR nejistotu vyřešit.
Samotné `20` či `20/10/5` nemá jednotky a vrací `missing_strength_unit`.
`0,5 g` a `500 mg` se porovnají jako stejná síla, stejně jako celý hmotnostní
tuple `75/25 mg` a `75 mg/25 mg`. `20 mg` není `20 µg`; jednotka se nikdy nehádá.
Frekvence se pouze textově normalizuje pro porovnání, nevykládá se jako dávkovací rada.

`selectMedicationCandidate(current, candidateId, { catalog })` znamená výslovný
uživatelský výběr. Navrhne katalogový název/sílu, dostupnou samostatnou `form` a
`ingredientText` do `active_substance`; staré `formAndPack` se na formu neparsuje.
Text látek je převzatý ze zdroje, nikoli nová standardizovaná INN/interakční databáze.
Původní OCR zůstane, `fieldOrigins` a `catalogSelection` pod `_core` popisují původ,
`catalogHistory` archivuje dřívější volby. Není tím zvoleno konkrétní balení ani kód SÚKL.
Volba ruší pacientskou kontrolu; neprázdná identifikační pole musí být znovu výslovně
potvrzena přes finalize. Existující konflikty volba sama neřeší.
Při pozdější změně názvu/síly/formy se navázané katalogové látky a forma vyprázdní,
pokud nebyly v témže volání výslovně potvrzeny. Zastaralá katalogová volba se deaktivuje.

`suggestMedicationGroups(medications, { catalog })` vrací jen sousední možné dvojice
z poznámky, kde druhý řádek nemá sílu a katalog dokládá shodu názvu nebo možné látky.
Výsledek má `observationIds`, `medicationIds`, `reason`, `requiresConfirmation: true`.
Složení se porovnává celé, ne jen společná složka kombinovaného léku.
Ani shodná látka neprokazuje klinickou zaměnitelnost; žádná skupina se sama nesloučí.

`mergeMedications(medications, { catalog, mergedId, groupConfirmed: true, weights? })`
bere nejméně dvě raw v2 nebo připravená pozorování jednoho druhu a vrací jeden
připravený v2 záznam. Potvrzení skupiny je povinné; neodvozuje se z fuzzy shody.
Váhy jsou nastavitelné pro každé ze šesti textových polí podle zdrojů
`box`, `printed_list`, `handwritten_list`, `manual`, `note` (neznámý styl).
Výchozí název/síla/látka/forma mají váhy 3/2/1/2 a dávkovací pole 0/2/2/3.
Neznámý note_style dostane nižší konfigurovanou váhu tištěného/ručně psaného zdroje,
pokud není `note` výslovně nastaveno. Váhy nejsou pravděpodobnosti.
Při konfliktu je příslušná hodnota prázdná, ne automaticky vítězná podle váhy.
Rozdíl frequency/amount vyžaduje kontrolu obou dávkovacích polí.

`sources` jsou všechny zdroje, `source` je první vstupní zdroj (ne pořadí spolehlivosti).
`_core.merge.fields` obsahuje návrhy a vážené alternativy s ID pozorování.
`_core.evidence` archivuje vstupní záznamy včetně jejich originálů, voleb a oprav.
`_core.original` u výsledku merge je počáteční sloučený návrh, nikoli přepis jediné fotky.
Původní nerozhodnuté konflikty zůstávají. Všechna neprázdná sloučená pole vyžadují
nové výslovné potvrzení; dílčí kontroly vstupů se nepřenášejí jako schválení celku.
Výstup dál prochází přes `finalizeMedication` a `createSharePayload`; wire formát se nemění.

## Export pro sdílení

`getShareIssues(medications, { unreadableCount = 0 })` vrací seznam
`{ index, field, code, message }`; prázdný seznam znamená připravenost pro export.
`createSharePayload(medications, options)` vrátí `{ medications }` nebo vyhodí
`ShareValidationError` se stejným polem `issues`. Neprovádí HTTP.

Povolená výstupní pole jsou přesně
`id, kind, name, active_substance, strength, form, frequency, amount, source, sources, note_style`.
`_core`, `uncertain_fields`, `conflicts` ani další vlastní vlastnosti se neposílají.
Limity: 1–50 položek, neprázdné name/id, jedinečná ID a nejvýše 100 Unicode code pointů
na každé textové pole včetně id (stejný počet jako Go `utf8.RuneCountInString`).
Editační textová pole se trimují, ale přes limit se neusekávají; původní text je
v original. ID se netrimuje. Řetězce s nepárovými zástupnými kódovými jednotkami
UTF-16 se odmítnou, protože Go by je při JSON dekódování nahradil jinými znaky.
Enumy a nejvýše tři zdroje se validují.

Export vyžaduje finalize a kontrolu aktuálních hodnot, blokuje později změněné hodnoty,
nevyřešené konflikty a neprázdná nejistá pole bez jejich výslovného potvrzení.
Prázdné nepovinné hodnoty se předají jako `null` — znamenají stále neznámý údaj,
nikoli úplnou anamnézu. Potvrzený přepis neznámého názvu lze sdílet i při `not_found`;
katalogová výstraha zůstává lokálně a neznamená neexistující lék.
Při potvrzené formě může katalog zůstat nejednoznačný; sdílení nepřenáší vybraný kód SÚKL.
`unreadableCount > 0` sdílení blokuje. Aplikace musí předat skutečný zbylý počet
ze všech analýz a ručního doplnění; výchozí 0 není automatické vyřešení nepřečtených řádků.

Níže je interní návrh vstupů pro slučování. Frontend ani backend se v tomto projektu
nemění. Pozorování je text přečtený z podkladu, nikoli potvrzený medikační záznam.
Adaptér může převést `frequency` a `amount` na čitelný text `dosage`, ale musí zachovat
také původní data.

## Pozorování k jednomu léku

```json
{
  "id": "note-1",
  "source": "handwritten_list",
  "values": {
    "name": "EUTHYROX",
    "strength": "75 mikrogramů",
    "dosage": "1-0-0"
  }
}
```

- `id`: unikátní neprázdný identifikátor pozorování. Žádné jméno nebo identifikátor pacienta.
- `source`: `box`, `printed_list`, `handwritten_list` nebo `manual`.
- `values.name`, `values.strength`, `values.dosage`: text nebo `null`, pokud údaj nebyl přečten. Původní dávkování zachovat i u týdenních režimů a užívání podle potřeby.
- Jeden seznam může obsahovat více léků. Jedna krabička a jeden řádek seznamu jsou dvě pozorování. Seskupení k témuž léku před voláním merge musí potvrdit volající aplikace.

## Výsledek párování

`matchMedication(input, catalog)` vrací `status`, `reason`, `candidates`.

| Stav | Význam |
| --- | --- |
| `matched` | Jediný kandidát pro zadaný název a sílu, stále vyžaduje potvrzení uživatelem |
| `needs_review` | Chybějící síla, více variant nebo síla odporující katalogu |
| `not_found` | Název v katalogu nebyl rozpoznán |

Všechny kandidáty vrací v původním formátu katalogu. Nevrací pravděpodobnost ani klinickou zaměnitelnost.
Název OCR může obsahovat svou přesně uvedenou sílu (`Advagraf 3 mg` + `strength: "3 mg"`).
Core tuto příponu použije pouze pro vyhledání, původní název nepřepisuje. Přípona s jinou
silou ani změna `RETARD` se nesmí potichu ignorovat.

## Volitelné katalogové návrhy od verze 0.4.0

`searchMedicationCandidates(query, catalog, { limit = 20 })` hledá prefixy slov názvu
a vrací `{ status, reason, candidates, total, truncated }`. Nejméně dva znaky dotazu,
limit 1–100. Při výsledcích je vždy `status: "needs_review"`, `reason: "name_search"`;
při nenalezení `not_found` / `unknown_name`. Přesný název se řadí před příbuzné názvy,
ale žádná položka se automaticky nepotvrzuje. Nehledá podle klinické zaměnitelnosti.

Původní export `@pillgaze/core/catalog` se nemění. Export `@pillgaze/core/sukl-catalog`
vrací kompatibilní pole kandidátů z oficiálního snapshotu SÚKL, nikoli nový API formát.
K základním `id`, `name`, `strength`, `ingredientText`, `formAndPack` přidává `form`,
`formCode`, `route`, `routeCode`, `ingredientCodes`, `productType`, `registrationStatus`,
`registrationNumber`, `holderCode`, `holderCountry`,
`source` a `packages: [{ suklCode, pack }]`. `formAndPack` u SÚKL variant popisuje
společnou formu; balení jsou výslovně v `packages`.

Jedna varianta může obsahovat více balení, ale ne různé síly, formy, cesty podání
nebo složení, registrace a držitele. Lokální ID varianty není konkrétní kód SÚKL. `matched` znamená jedinou
variantu podle názvu a síly, ne vybrané balení, potvrzení dostupnosti nebo léčby.
Chybějící síla ani nerozlišená forma se nevymýšlí. Původ, platnost a podmínky jsou
v `@pillgaze/core/sukl-metadata` a musí být zpřístupněné uživateli spolu s výsledky.

## Výsledek sloučení

`mergeMedicationEvidence(observations, options)` vrací `fields` a `hasConflicts`. Každé pole obsahuje:

- `status`: `missing`, `single_source`, `agrees` nebo `conflict`.
- `value`: zjištěná hodnota, při konfliktu nebo chybějícím údaji `null`.
- `suggestedValue`: nejvýše řazený návrh, při konfliktu nesmí být považován za potvrzený výsledek.
- `alternatives`: všechny nalezené hodnoty, jejich `evidenceId`, `source` a konfigurovaná `weight`.

Výchozí váhy jsou pouze startovní konfigurace k ladění s mentorem. Nejsou pravděpodobnostmi. Obecný pokyn na krabičce má pro pacientovo dávkování váhu 0, zůstává však dohledatelný v `alternatives`.

PIN transport a lékařská kontrola interakcí patří do API a lékařského prostředí.
Core připraví pouze validovaný share JSON; PIN ani interakce neimplementuje.
