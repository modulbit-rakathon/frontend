# PillGaze core

PillGaze core doplňuje přepis léků z fotografií o **katalogovou kontrolu, označení
nejistot a dohledatelnost údajů**. Aplikace tak nemusí jen zobrazit, co přečetla AI:
může upozornit na nesoulad s katalogem a připravit údaje ke kontrole pacientem
a následnému předání lékaři.

Pro projekt přináší:

- **Kontrolu názvu a síly proti katalogu léčiv**, včetně volitelného katalogu SÚKL.
  Nabízí kandidáty, ale neprovádí automatickou záměnu za jiný lék nebo sílu.
- **Zachování neznámých údajů a rozporů.** Chybějící dávkování si nevymýšlí;
  vážené porovnání potvrzených skupin podkladů zachová konfliktní hodnoty.
- **Historii pacientských oprav.** Původní přepis zůstává dohledatelný i po změně
  údajů ve formuláři.
- **Kontrolovaný export pro API v2.** Připraví správný JSON pro sdílení a blokuje
  nevyřešené konflikty místo jejich tichého zahození.

Tato logika je na jednom místě, takže ji frontend nemusí vytvářet znovu.
Core je JavaScriptová knihovna bez vlastního serveru a npm závislostí; do aplikace
se musí výslovně zapojit. Katalogová shoda není potvrzení užívání ani správnosti
léčby a nenahrazuje kontrolu pacientem a lékařem.

## Začni tady

```bash
cd ~/Rakathon/core
npm test
npm run demo
npm run demo:frontend
npm run demo:backend
npm run demo:sukl
npm run demo:v2
npm run demo:issue1
npm run verify:package
```

Node.js 20 nebo novější. `npm install` není potřeba. V projektu nejsou síťová volání.

Verze **0.6.1 podporuje API v2**: všech šest textových polí a nejistot, top-level
`id`, `kind`, `note_style`, `sources` a `conflicts`. Přijme celý výsledek analýzy
i přímo `Medication[]`. Úpravy starým čtyřpolovým formulářem další údaje nezahodí.
Onkologický režim se zachová jako `kind: "regimen"`, nepáruje se jako lék a nedostane
vymyšlené složení či dávky.

Řešení [issue #1](https://github.com/modulbit-rakathon/core/issues/1) přidává návrhy
pro překlepy a alternativní značky, výslovný výběr katalogové varianty s doplněním
látek a jejich původu a vážené slučování přímo pro `Medication[]`. Nečitelný název
se neopravuje automaticky a vedlejší řádek se jen navrhne ke kontrole, nikdy neslije
bez potvrzení skupiny. Ani přesná katalogová shoda nepotvrdí OCR označené jako nejisté.

Před napojením na frontend verze 0.6.1 opravuje opakované použití starých potvrzení
po změně názvu/síly/formy, kontroluje i změny původu dat a doplňuje blokující počet
u starých textových hlášení o nepřečtených řádcích. Kandidáti jsou nezávislé kopie,
takže změna formulářového objektu nemůže přepsat sdílený katalog.
`npm run verify:package` vytvoří TGZ, rozbalí ho do dočasného spotřebitele a spustí
12 kontrol se skutečným SÚKL katalogem. Na konci dočasné soubory odstraní.
Jde o syntetický technický důkaz toku dat, ne o měření správnosti OCR.

`createSharePayload` vytváří přesný JSON pro `/api/share`, bez `_core` a dalších
nepovolených polí. Blokuje nepotvrzené záznamy, nevyřešené konflikty a nepotvrzené
neprázdné nejisté hodnoty; neznámé nepovinné hodnoty posílá jako `null`. Kontroluje
1–50 položek, unikátní ID a limit 100 Unicode znaků. HTTP ani PIN negeneruje.
Instrukce pro Jonáše a Vítka jsou v [INTEGRATION.md](INTEGRATION.md).

**Volitelný oficiální katalog SÚKL** a hledání návrhů z verze 0.4.0 zůstávají.
Větší katalog se použije až vědomou změnou importu; katalog není klinická kontrola.

**Tento projekt je jen core.** Nemění ani nespouští frontend nebo backend a neimplementuje
HTTP upload, OCR ani autentizaci. Příklady běží nad pevnými JSON fixtures, nikoli nad
skutečným rozpoznáváním. Frontend i backend si dál vlastní jejich autoři.

1. Otevři `fixtures/conflicting-strength.json`. Jde o ručně připravený vzor výsledků OCR, nikoli výstup skutečného modelu.
2. Spusť demo. Uvidíš kandidáty z katalogu, konflikt dvou sil a výsledný text.
3. Přidej nový příklad do `fixtures/` a příslušný test do `test/core.test.js`.
4. Jako první vlastní úkol připrav 5 vzorových případů z dodaných seznamů: více sil stejného názvu, překlep, týdenní užívání, náplast a opakovaná fotka téhož přípravku. Očekávaná data ručně porovnej s podkladem.

## Kdo co vlastní

| Část | Vlastník | Co potřebuje od ostatních |
| --- | --- | --- |
| `core` | vlcak27 | Skutečné odpovědi OCR a příklady chyb |
| `frontend` | jonashubeny | Později import funkcí a zobrazení kandidátů/konfliktů |
| `backend` | Vítek / smoliicek | Multipart `image` + `source`, odpověď podle dodané ukázky |

Frontend a backend mohou pokračovat nad pevnými JSON příklady. Go backend JavaScript přímo neimportuje; pro první integraci použije JS funkce frontend a backend validuje přijaté údaje samostatně.

## Rozhraní

```js
import { matchMedication, mergeMedicationEvidence, formatDoctorText } from './src/index.js';

const match = matchMedication({ name: 'EUTHYROX', strength: '50 mikrogramů' }, catalog);
const merged = mergeMedicationEvidence(observations);
const text = formatDoctorText([merged]);
```

Podrobnosti jsou v [CONTRACT.md](CONTRACT.md). V2 adaptér přijímá backendové `Medication`;
interní formát pro vážené slučování více pozorování je popsaný odděleně.
Pro API v2 použijte `mergeMedications`, nikoli ruční převod na staré `values`.
Návrhy jsou v `_core.suggestions`; výběr obsluhuje `selectMedicationCandidate`
a možné sousední alternativy `suggestMedicationGroups`. Podrobný postup je v INTEGRATION.

`matched` znamená jediný kandidát v dodaném katalogu podle názvu a síly. Neznamená potvrzení, že pacient tento lék užívá. Pro potvrzení musí aplikace dál použít uživatele a pro konečnou kontrolu lékaře.

`mergeMedicationEvidence()` dostává podklady k jednomu již seskupenému léku. Zatím automaticky neurčuje, zda dva záznamy popisují tentýž přípravek. Konflikty zachovává a váhy používá pouze k seřazení návrhů. U názvů podporuje normalizaci velikosti písmen a diakritiky a přesně odvozené varianty názvu se silou. Překlepy, různé obchodní názvy a klinickou zaměnitelnost zatím neodhaduje.

## Původní katalog ze zadání

- Zdroj: dodaný `Katalog_leciv_kompletni_309.xlsx`, list `Katalog léčiv kompletní`.
- 309 původních řádků, 303 záznamů po spojení šesti dvojic obsahově shodných řádků.
- Každý záznam uchovává odkaz na všechny původní řádky. Lokální ID nejsou kódy SÚKL.
- `ingredientText` uchovává původní text účinných látek. Není to normalizovaná databáze látek nebo interakcí.
- Metadata obsahují SHA-256 zdrojového souboru. Neproběhlo nezávislé medicínské ověření katalogu.

Znovuvytvoření katalogu pomocí Pythonu 3 bez dalších knihoven:

```bash
python3 scripts/import_catalog.py ../podklady/Data/Katalog_leciv_kompletni_309.xlsx
npm test
```

## Rozšířený katalog SÚKL

Zdroj: **SÚKL**, [Databáze léčivých přípravků DLP](https://opendata.sukl.cz/?q=katalog/databaze-lecivych-pripravku-dlp),
veřejná CSV data v ZIP bez přihlášení. Podmínky umožňují šíření a komerční užití s uvedením
zdroje a zachováním významu dat; [podmínky užití SÚKL](https://opendata.sukl.cz/?q=podminky-uziti-otevrenych-dat)
platí i pro tuto převzatou část. SÚKL tuto aplikaci neschvaluje ani nepodporuje.

- Snapshot `DLP20260925.zip`, platnost **1.–31. října 2026**, nikoli živá databáze.
- **21 226 variant léčiv, 61 354 balení s původními sedmimístnými kódy SÚKL.**
- Jen stav `REG=R` (registrované léčivé přípravky). Ostatní stavy, například pozastavené
  registrace nebo potraviny pro zvláštní lékařské účely, nejsou v tomto výběru.
- Spojují se pouze balení se zcela shodným názvem, silou, formou, cestou podání,
  kódy látek, typem přípravku, registračním číslem a držitelem. Gel a krém, různé síly
  ani odlišné registrace a držitelé se neslučují.
- Lokální `sukl-variant-…` není kód SÚKL. Skutečné kódy jsou v `packages[].suklCode`,
  původní velikost balení v `packages[].pack`. `formAndPack` u těchto variant popisuje
  společnou lékovou formu, nikoli jedno konkrétní balení.
- `ingredientText` je převzatý seznam názvů látek, ne doporučení alternativ či dávkování.
  Registrace neprokazuje současnou dostupnost v lékárně ani užívání pacientem.
- Soubory `data/sukl-catalog.json` a `data/sukl-catalog.metadata.json` obsahují data
  a původ, platnost, SHA-256 i odkaz na podmínky. Je to výběr polí DLP, nikoli kompletní
  registr, příbalové letáky nebo databáze interakcí.

Použití v Jonášově frontendu (Vite); přístup k internetu ani API klíč nejsou potřeba:

```js
import { searchMedicationCandidates, createAnalyzePhoto } from '@pillgaze/core';
import catalog from '@pillgaze/core/sukl-catalog';
import metadata from '@pillgaze/core/sukl-metadata';

const suggestions = searchMedicationCandidates('Ibalgin', catalog, { limit: 20 });
// suggestions: { status, reason, candidates, total, truncated }
// Návrhy mají vždy needs_review; nejsou potvrzení ani doporučení záměny.

const analyzePhoto = createAnalyzePhoto({ analyze: rawAnalyzePhoto, catalog });
// Stejný adaptér API jako předtím; žádná změna backendového JSONu.
```

`rawAnalyzePhoto` dodává Jonášův HTTP klient. U kandidátů je třeba ukazovat sílu,
formu, cestu podání a zdroj; nevybírat první výsledek automaticky. Vyhledávání pracuje
s prefixy slov obchodních názvů, nikoli s účinnými látkami jako náhradami jiného léku.
Např. dotaz `ibuprofen` automaticky nenabídne Ibalgin jako klinickou záměnu.
Návrhy při psaní nemají odstraňovat původní OCR ani jeho nejistoty.

Větší katalog má přibližně 12 MiB JSON. Importujte jej jen tam, kde je potřeba;
Vite umožňuje také líné načtení `await import('@pillgaze/core/sukl-catalog')`.
Původní malý `@pillgaze/core/catalog` je stále dostupný a nebyl automaticky nahrazen.
Po `validTo` je nutné označit data jako starší a provést aktualizaci; core se samo
na síť nepřipojuje. Registrovaný katalog nepokrývá každý starší, zahraniční nebo
doplňkový přípravek, proto `not_found` neznamená neexistující lék.

Reprodukovatelný import pomocí Pythonu 3 bez knihoven navíc:

```bash
curl --fail --location https://opendata.sukl.cz/soubory/SOD20260925/DLP20260925.zip -o DLP20260925.zip
python3 scripts/import_sukl.py DLP20260925.zip \
  --source-url https://opendata.sukl.cz/soubory/SOD20260925/DLP20260925.zip
npm run test:import
npm test
npm run demo:sukl
```

Pro další měsíc použijte skutečný odkaz z katalogu SÚKL, zkontrolujte platnost a změny
datového rozhraní a aktualizujte očekávané počty ve snapshot testu. Importér kontroluje
sloupce, odkazy a duplicitní kódy; při změně struktury má selhat, ne tiše hádat.

### Hranice podle zadání Rakathonu

Katalogové návrhy nejsou kontrola interakcí ani identifikace onkologických režimů.
Podle dodaného zadání se mají interakce a informace o onkologických režimech zobrazovat
odděleně, pouze na vyžádání a jen v rozhraní lékaře. Tento core je zatím neimplementuje.
Při lokálním vyhledávání se žádný pacientský seznam neposílá SÚKL ani jiné službě.
Mentorem doporučený [HemOnc](https://hemonc.org/) je podklad pro budoucí samostatné
lékařské zobrazení režimů. Není automaticky importovaný ani klinicky validovaný tímto
core; před použitím je nutné ověřit konkrétní režim, aktuálnost a podmínky zdroje.

## Postup pro tým

1. vlcak27 pracuje v `core`, jonashubeny ve `frontend`, smoliicek v `backend`.
2. Nejprve si společně odsouhlaste `CONTRACT.md` a jeden JSON příklad. Změny formátu oznamujte předem.
3. První napojení proveďte v samostatné větvi frontendu. Připněte konkrétní verzi `core`, aby rozpracovaná změna neměnila aplikaci kolegům.
4. Zdrojový kód patří do soukromého repozitáře [modulbit-rakathon/core](https://github.com/modulbit-rakathon/core), výchozí větev `main`.
5. Před commitem nastavte vlastní jméno a e-mail a zkontrolujte změny.

Stažení zdrojů a místní ověření:

```bash
git clone https://github.com/modulbit-rakathon/core.git
cd core
npm test
npm run demo:backend
```

Repozitář je soukromý; přístup musí mít i spoluhráči. Nenastavujte jako remote `frontend`
ani `backend`, ty mají vlastní zdrojový kód.

## Balíček pro Jonáše

Ve [vydání v0.6.1](https://github.com/modulbit-rakathon/core/releases/tag/v0.6.1) je
`pillgaze-core-0.6.1.tgz`: npm balíček funkcí a obou katalogů pro frontend, nikoli server.
Archiv vzniká příkazem `npm pack`, necommituje se do zdrojů.
Jonáš si jej stáhne přes GitHub Releases nebo ve svém frontendu:

```bash
mkdir -p vendor
gh release download v0.6.1 --repo modulbit-rakathon/core --pattern pillgaze-core-0.6.1.tgz --dir vendor
npm install ./vendor/pillgaze-core-0.6.1.tgz
```

Pro soukromý repozitář musí být přihlášený přes `gh auth login` a mít přístup.
Ve frontendu se má verzovat `vendor/` archiv i změny `package.json` a lockfile,
aby instalace fungovala i spoluhráčům. Konkrétní importy jsou v [INTEGRATION.md](INTEGRATION.md).
Katalog a jeho zdroje musí tým před dalším sdílením schválit; pacientské dokumenty ani fotky
z `podklady/` nejsou součástí balíčku ani tohoto repozitáře.

## Další malé úkoly

- Přidat ověřené aliasy názvů s odkazem na zdroj. Podobný název nemusí znamenat stejný přípravek.
- Rozšířit ručně ověřené případy překlepů z anonymizovaných skutečných OCR JSONů.
  Silně zkomolené názvy (`Atevhon`, `Doremal`) nyní mohou zůstat bez kandidáta;
  jejich očekávaný lék se nevnucuje bez důkazů.
- Přidat kontrolu stáří katalogu a rozšířit ručně ověřené regresní případy.
- Domluvit s frontendem skupiny léků: opakované fotografie a různé síly stejného přípravku se nemají automaticky slít.
- Srovnat výstup s modelovými případy. Dosavadní automatické testy neověřují kvalitu OCR ani medicínskou správnost.

## Kontrola vůči zadání a repozitářům

Zkontrolovaný backend: [`c13149d`](https://github.com/modulbit-rakathon/backend/tree/c13149d17ea4480eedd37addc3a2a3a8fafa33e9);
frontend: [`a19a49e`](https://github.com/modulbit-rakathon/frontend/tree/a19a49e4d3f698a93723806ef1521c9ebf8e8290).
Jde o stav těchto revizí, nikoli příslib stavu pozdějšího nasazení.

| Oblast zadání | Stav a další krok |
| --- | --- |
| Skutečné čtení a anonymní přenos | Frontend už má `api.js` a Scan volá skutečné analyze s pevným source box. Core a volba dalších zdrojů ještě nejsou zapojené; share zůstává mock s PINem `1234`. API klíč v `VITE_` proměnné je veřejný ve výsledném bundlu; způsob autentizace musí domluvit frontend s backendem. |
| Zachování zdrojů a pacientská kontrola | `Scan.jsx` ukládá jen hodnoty formuláře a source. Je nutné ukládat celý výsledek `finalizeMedication`, zobrazit všechny nejistoty a nabídnout jejich vyřešení. |
| Předání nevyřešených rozporů | V2 při sdílení zakazuje `conflicts` a `uncertain_fields`. Core proto blokuje nevyřešené rozpory; jejich předání lékaři by vyžadovalo domluvenou změnu API, ne jen core. Pacient nesmí dávkování hádat. |
| Vážené slučování zdrojů | Core 0.6 má `mergeMedications` přímo nad v2, váhy podle note_style, zdroje i konflikty. Seskupení a výsledné hodnoty musí potvrdit člověk; napojení na UI je na frontendu. |
| Lékařské rozhraní | V `App.jsx` není route `/doctor` ani příjem přes claim, editace a kopírování do dokumentace. Tisk pacientské zprávy tuto část nenahrazuje. |
| Interakce a onkologické informace | Zadání je chce odděleně, na vyžádání a jen pro lékaře. Frontend má mock interakce automaticky i na pacientské zprávě; core nemá ověřenou interakční databázi ani rozklad režimů. |
| PIN | Backendový kód má 4 číslice, 180 s, jednorázový claim a paměťové úložiště. Živé share/claim bez API klíče nebyly ověřeny. Odkaz na `/pin` v `Report.jsx` je zatím jen v prázdném stavu seznamu. |
| Anonymita | Core nikam nic neodesílá a exportuje jen povolená pole; tím ale neanonymizuje text či fotku obsahující osobní údaje. Ty se nesmějí dostat do API/logů. |

Backendový autor v [komentáři](https://github.com/modulbit-rakathon/backend/issues/1#issuecomment-6216986813)
uvádí záměny ručně psaných názvů za jiné existující léky. Shoda v katalogu proto
nenahrazuje lidskou kontrolu. Pro demo nejprve dokončete tok
foto → kontrola → skutečný PIN → lékař; až potom přidávejte další medicínské funkce.
