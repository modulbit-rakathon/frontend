import { DEFAULT_WEIGHTS, mergeEvidenceFields } from './mergeEvidence.js';
import { MEDICATION_FIELDS, isObject, normalizeMedication } from './medicationModel.js';
import { prepareMedications } from './frontendAdapter.js';

const defaults = Object.fromEntries(MEDICATION_FIELDS.map(field => [
  field, { ...DEFAULT_WEIGHTS[['frequency', 'amount'].includes(field) ? 'dosage'
    : field === 'strength' ? 'strength' : 'name'] },
]));

function weightedSource(med) {
  return med.source === 'note' ? med.note_style === 'printed' ? 'printed_list'
    : med.note_style === 'handwritten' ? 'handwritten_list' : 'note' : med.source;
}

/** The caller confirms identity/grouping; weights cannot approve a treatment. */
export function mergeMedications(medications, {
  catalog, mergedId, groupConfirmed = false, weights = {},
} = {}) {
  if (groupConfirmed !== true) throw new TypeError('Confirm the medication group before merging.');
  if (!Array.isArray(medications) || medications.length < 2) throw new TypeError('Merge at least two medication observations.');
  if (typeof mergedId !== 'string' || !mergedId.trim()) throw new TypeError('A merged medication ID is required.');
  if (!Array.isArray(catalog)) throw new TypeError('Catalog must be an array.');
  if (!isObject(weights)) throw new TypeError('Weights must be an object.');
  const meds = Array.from(medications, med => normalizeMedication(med));
  if (new Set(meds.map(med => med.kind)).size !== 1) throw new TypeError('Do not merge drugs with regimens.');
  const evidence = meds.map((med, index) => ({
    id: medications[index]._core?.observationId ?? med.id,
    source: weightedSource(med),
    values: Object.fromEntries(MEDICATION_FIELDS.map(field => [field, med[field] || null])),
  }));
  // Unknown note style gets the lower configured note weight, never a guessed style.
  const fieldDefaults = Object.fromEntries(MEDICATION_FIELDS.map(field => {
    const configured = { ...defaults[field], ...weights[field] };
    return [field, { ...defaults[field], note: Math.min(configured.printed_list, configured.handwritten_list) }];
  }));
  const merged = mergeEvidenceFields(evidence, fieldDefaults, { weights });
  const byId = new Map(evidence.map((item, index) => [item.id, meds[index]]));
  const conflicts = meds.flatMap(med => structuredClone(med.conflicts));
  for (const [field, result] of Object.entries(merged.fields)) {
    if (result.status === 'conflict') {
      conflicts.push({
        field,
        values: result.alternatives.map(item => ({ source: byId.get(item.evidenceId).source, value: item.value })),
      });
    }
  }
  const conflicted = new Set(conflicts.map(conflict => conflict.field));
  const values = Object.fromEntries(MEDICATION_FIELDS.map(field => [
    field, conflicted.has(field) ? null : merged.fields[field].value,
  ]));
  const uncertain = new Set(meds.flatMap(med => med.uncertain_fields));
  for (const field of MEDICATION_FIELDS) if (values[field] || conflicted.has(field)) uncertain.add(field);
  if (conflicted.has('frequency') || conflicted.has('amount')) {
    uncertain.add('frequency'); uncertain.add('amount');
  }
  const [result] = prepareMedications([{
    ...values, id: mergedId, kind: meds[0].kind, source: meds[0].source,
    sources: [...new Set(meds.flatMap(med => med.sources))], conflicts,
    uncertain_fields: [...uncertain],
    ...(meds.every(med => med.source === 'note' && med.note_style === meds[0].note_style)
      && meds[0].note_style !== undefined ? { note_style: meds[0].note_style } : {}),
  }], { catalog, analysisId: `merge:${mergedId}` });
  result._core.merge = {
    groupConfirmed: true, fields: merged.fields,
    observationIds: evidence.map(item => item.id),
  };
  result._core.evidence = meds.map((med, index) => ({
    ...med,
    ...(medications[index]._core ? { _core: structuredClone(medications[index]._core) } : {}),
  }));
  return result;
}
