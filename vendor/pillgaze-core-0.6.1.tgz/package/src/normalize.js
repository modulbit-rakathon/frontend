export function normalizeText(value) {
  return String(value ?? '').normalize('NFKD').replace(/\p{M}/gu, '')
    .toLowerCase().trim().replace(/\s+/g, ' ');
}

// Unit conversion is used only for comparing strengths, never for changing a dose.
export function strengthKey(value) {
  let normalized = normalizeText(value)
    .replace(/[µμ]/g, 'u')
    .replace(/mikrogram(?:u|y)?\b/g, 'ug')
    .replace(/(\d)[ \u00a0](?=\d{3}(?:\D|$))/g, '$1')
    .replace(/(\d),(?=\d)/g, '$1.');
  // A shared trailing mass unit applies only to a complete numeric tuple.
  const tuple = normalized.match(/^(\d+(?:\.\d+)?(?:\s*\/\s*\d+(?:\.\d+)?)+)\s*(mg|ug|g)$/);
  if (tuple) normalized = tuple[1].split('/').map(number => `${number.trim()} ${tuple[2]}`).join('/');
  return normalized
    .replace(/(\d+(?:\.\d+)?)\s*(mg|ug|g)\b/g, (_, number, unit) => {
      const factor = { g: 1_000_000, mg: 1_000, ug: 1 }[unit];
      return `${Number((Number(number) * factor).toPrecision(12))} ug`;
    })
    .replace(/\s*\/\s*/g, '/');
}

export function hasUnitlessStrength(value) {
  return /^\d+(?:[.,]\d+)?(?:\s*\/\s*\d+(?:[.,]\d+)?)*$/.test(String(value ?? '').trim());
}

export function nameKeys(name, strength) {
  const full = normalizeText(name);
  const keys = new Set([full]);
  const dose = normalizeText(strength);
  // Catalogue names and OCR may include strength: AGEN 5, Advagraf 3 mg.
  // Remove a suffix only when it is exactly the record's stated strength.
  const scalar = dose.match(/^(\d+(?:[.,]\d+)?)\s*(mg|g|ug|[µμ]g|mikrogramu)$/);
  if (scalar) {
    const suffix = full.match(/^(.*?)\s+(\d+(?:[.,]\d+)?\s*(?:mg|g|ug|[µμ]g|mikrogramu))$/);
    if (suffix && strengthKey(suffix[2]) === strengthKey(dose)) keys.add(suffix[1].trim());
    for (const suffix of [dose, scalar[1]]) {
      if (full.endsWith(` ${suffix}`)) keys.add(full.slice(0, -suffix.length).trim());
    }
  }
  return [...keys];
}
