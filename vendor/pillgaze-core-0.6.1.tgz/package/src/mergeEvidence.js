import { normalizeText, strengthKey, nameKeys } from './normalize.js';

export const DEFAULT_WEIGHTS = {
  name: { box: 3, printed_list: 2, handwritten_list: 1, manual: 2 },
  strength: { box: 3, printed_list: 2, handwritten_list: 1, manual: 2 },
  dosage: { box: 0, printed_list: 2, handwritten_list: 2, manual: 3 },
};

/**
 * Evidence must refer to ONE medication, grouped by the caller.
 * Weights rank suggestions; they never resolve a conflict automatically.
 * "value" means an extracted value, not clinical confirmation.
 */
export function mergeMedicationEvidence(evidence, { weights = {} } = {}) {
  return mergeEvidenceFields(evidence, DEFAULT_WEIGHTS, { weights });
}

export function mergeEvidenceFields(evidence, defaults, { weights = {} } = {}) {
  if (!Array.isArray(evidence)) throw new TypeError('Evidence must be an array.');
  if (!weights || typeof weights !== 'object' || Array.isArray(weights)
      || Object.keys(weights).some(field => !Object.hasOwn(defaults, field))) {
    throw new TypeError('Weights must use known fields.');
  }
  const ids = new Set();
  for (const item of Array.from(evidence)) {
    if (!item || typeof item.id !== 'string' || !item.id.trim() || ids.has(item.id)) {
      throw new TypeError('Each observation needs a unique non-empty id.');
    }
    ids.add(item.id);
    if (!Object.hasOwn(defaults.name, item.source)) {
      throw new TypeError(`Unknown source: ${item.source}`);
    }
  }
  const byId = new Map(evidence.map(item => [item.id, item]));
  const fields = {};
  for (const field of Object.keys(defaults)) {
    if (weights[field] !== undefined && (!weights[field] || typeof weights[field] !== 'object'
        || Array.isArray(weights[field])
        || Object.keys(weights[field]).some(source => !Object.hasOwn(defaults[field], source)))) {
      throw new TypeError('Weights must use known sources.');
    }
    const sourceWeights = { ...defaults[field], ...weights[field] };
    if (Object.values(sourceWeights).some(w => !Number.isFinite(w) || w < 0)) {
      throw new TypeError('Weights must be finite non-negative numbers.');
    }
    const alternatives = [];
    for (const item of evidence) {
      const raw = item.values?.[field];
      if (raw == null || raw === '') continue;
      if (typeof raw !== 'string') throw new TypeError(`${field} must be a string or null.`);
      if (!raw.trim()) continue;
      alternatives.push({
        value: raw.trim(), evidenceId: item.id, source: item.source,
        weight: sourceWeights[item.source],
      });
    }
    alternatives.sort((a, b) => b.weight - a.weight || a.evidenceId.localeCompare(b.evidenceId));
    const eligible = alternatives.filter(a => a.weight > 0);
    const groups = new Set(eligible.map(item => field === 'strength' ? strengthKey(item.value)
      : field === 'name' ? nameKeys(item.value, byId.get(item.evidenceId).values?.strength).at(-1)
        : normalizeText(item.value)));
    const conflict = groups.size > 1;
    fields[field] = {
      status: groups.size === 0 ? 'missing' : conflict ? 'conflict'
        : eligible.length > 1 ? 'agrees' : 'single_source',
      value: groups.size === 1 ? eligible[0].value : null,
      suggestedValue: eligible[0]?.value ?? null,
      alternatives,
    };
  }
  return { fields, hasConflicts: Object.values(fields).some(f => f.status === 'conflict') };
}
