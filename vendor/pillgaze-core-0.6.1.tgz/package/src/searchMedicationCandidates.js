import { normalizeText } from './normalize.js';

/** Name suggestions only: never substitutions or confirmed patient medication. */
export function searchMedicationCandidates(query, catalog, { limit = 20 } = {}) {
  if (typeof query !== 'string' || normalizeText(query).length < 2) {
    throw new TypeError('Search query must contain at least two characters.');
  }
  if (!Array.isArray(catalog)) throw new TypeError('Catalog must be an array.');
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) {
    throw new TypeError('limit must be an integer between 1 and 100.');
  }
  const name = normalizeText(query);
  const tokens = name.split(' ');
  const ranked = [];
  for (const candidate of catalog) {
    const normalized = normalizeText(candidate.name);
    const words = normalized.split(' ');
    if (tokens.every(token => words.some(word => word.startsWith(token)))) {
      ranked.push({ candidate, exact: normalized === name });
    }
  }
  ranked.sort((a, b) => Number(b.exact) - Number(a.exact)
    || a.candidate.name.localeCompare(b.candidate.name, 'cs')
    || a.candidate.strength.localeCompare(b.candidate.strength, 'cs', { numeric: true })
    || a.candidate.id.localeCompare(b.candidate.id));
  return {
    status: ranked.length ? 'needs_review' : 'not_found',
    reason: ranked.length ? 'name_search' : 'unknown_name',
    candidates: ranked.slice(0, limit).map(item => structuredClone(item.candidate)),
    total: ranked.length,
    truncated: ranked.length > limit,
  };
}
