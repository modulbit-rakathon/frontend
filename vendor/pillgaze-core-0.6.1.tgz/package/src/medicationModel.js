export const MEDICATION_FIELDS = Object.freeze([
  'name', 'active_substance', 'strength', 'form', 'frequency', 'amount',
]);
export const MEDICATION_SOURCES = Object.freeze(['box', 'note', 'manual']);
const KINDS = ['drug', 'regimen'];
const NOTE_STYLES = ['printed', 'handwritten'];

export const isObject = value => value !== null && typeof value === 'object' && !Array.isArray(value);

export function medicationText(value, path) {
  if (value == null) return '';
  if (typeof value !== 'string') throw new TypeError(`${path} must be text or null.`);
  return value.trim();
}

export function medicationFields(value, path) {
  if (!Array.isArray(value) || [...value].some(field => !MEDICATION_FIELDS.includes(field))) {
    throw new TypeError(`${path} must contain only ${MEDICATION_FIELDS.join(', ')}.`);
  }
  return [...new Set(value)];
}

export function medicationConflicts(value = []) {
  if (!Array.isArray(value)) throw new TypeError('conflicts must be an array.');
  return Array.from(value, conflict => {
    if (!isObject(conflict) || !MEDICATION_FIELDS.includes(conflict.field)
        || !Array.isArray(conflict.values) || conflict.values.length === 0) {
      throw new TypeError('Each conflict needs a medication field and source values.');
    }
    return {
      field: conflict.field,
      values: Array.from(conflict.values, item => {
        if (!isObject(item) || !MEDICATION_SOURCES.includes(item.source) || typeof item.value !== 'string') {
          throw new TypeError('Conflict values require a known source and text.');
        }
        return { source: item.source, value: item.value };
      }),
    };
  });
}

export function normalizeMedication(med, { fallbackId, legacy = false } = {}) {
  if (!isObject(med)) throw new TypeError('Medication must be an object.');
  const id = med.id === undefined ? fallbackId : med.id;
  if (typeof id !== 'string') throw new TypeError('Medication id must be text.');
  if (!id.trim()) throw new TypeError('Medication id is required.');
  const kind = med.kind === undefined && legacy ? 'drug' : med.kind;
  if (!KINDS.includes(kind)) throw new TypeError('kind must be text: drug or regimen.');
  if (!MEDICATION_SOURCES.includes(med.source)) throw new TypeError('source must be box, note or manual.');
  if (med.note_style !== undefined && med.note_style !== null && !NOTE_STYLES.includes(med.note_style)) {
    throw new TypeError('note_style must be text: printed, handwritten or null.');
  }
  if (med.sources !== undefined && (!Array.isArray(med.sources) || med.sources.length > 3
      || [...med.sources].some(source => !MEDICATION_SOURCES.includes(source)))) {
    throw new TypeError('sources must contain at most three known sources.');
  }
  return {
    id,
    kind,
    ...Object.fromEntries(MEDICATION_FIELDS.map(field => [field, medicationText(med[field], field)])),
    source: med.source,
    ...(med.note_style !== undefined ? { note_style: med.note_style } : {}),
    sources: [...new Set([med.source, ...(med.sources ?? [])])],
    conflicts: medicationConflicts(med.conflicts),
    uncertain_fields: medicationFields(med.uncertain_fields ?? [], 'uncertain_fields'),
  };
}
