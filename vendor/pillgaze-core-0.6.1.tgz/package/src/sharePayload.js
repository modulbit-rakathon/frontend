import {
  MEDICATION_FIELDS, MEDICATION_SOURCES, isObject, normalizeMedication,
} from './medicationModel.js';

export class ShareValidationError extends Error {
  constructor(issues) {
    super('Medication list is not ready for sharing.');
    this.name = 'ShareValidationError';
    this.issues = issues;
  }
}

/** Explain blocked sharing without logging medication data or losing warnings. */
export function getShareIssues(medications, { unreadableCount = 0 } = {}) {
  const issues = [];
  const add = (index, field, code, message) => issues.push({ index, field, code, message });
  if (!Number.isSafeInteger(unreadableCount) || unreadableCount < 0) {
    add(null, null, 'invalid_unreadable_count', 'Unreadable count must be a nonnegative integer.');
  } else if (unreadableCount > 0) {
    add(null, null, 'unreadable_items', 'Review and complete unreadable items before sharing.');
  }
  if (!Array.isArray(medications) || medications.length < 1 || medications.length > 50) {
    add(null, null, 'item_count', 'Share between 1 and 50 medications.');
    return issues;
  }
  const ids = new Set();
  for (const [index, current] of medications.entries()) {
    let med;
    try {
      med = normalizeMedication(current);
    } catch (error) {
      if (!(error instanceof TypeError)) throw error;
      add(index, null, 'invalid_medication', error.message);
      continue;
    }
    if (!med.name) add(index, 'name', 'required', 'Medication name is required.');
    if (ids.has(med.id)) add(index, 'id', 'duplicate_id', 'Medication IDs must be unique within a share.');
    ids.add(med.id);
    for (const field of ['id', ...MEDICATION_FIELDS]) {
      if ([...med[field]].length > 100) add(index, field, 'too_long', 'Strings are limited to 100 characters.');
      if (/[\uD800-\uDFFF]/u.test(med[field])) {
        add(index, field, 'invalid_unicode', 'Text contains an unpaired UTF-16 surrogate.');
      }
    }
    const metadata = current._core;
    if (!isObject(metadata) || metadata.version !== 1 || metadata.patientReviewed !== true
        || !isObject(metadata.reviewedValues) || !Array.isArray(metadata.patientConfirmedFields)
        || [...metadata.patientConfirmedFields].some(field => !MEDICATION_FIELDS.includes(field))
        || !isObject(metadata.reviewedProvenance) || !Array.isArray(metadata.reviewedProvenance.sources)
        || [...metadata.reviewedProvenance.sources].some(source => !MEDICATION_SOURCES.includes(source))) {
      add(index, null, 'patient_review_required', 'Confirm the medication before sharing.');
    } else {
      if (metadata.reviewedKind !== med.kind || metadata.reviewedSource !== med.source
          || metadata.reviewedProvenance.note_style !== (med.note_style ?? null)
          || JSON.stringify([...metadata.reviewedProvenance.sources].sort()) !== JSON.stringify([...med.sources].sort())
          || MEDICATION_FIELDS.some(field => metadata.reviewedValues[field] !== med[field])) {
        add(index, null, 'changed_after_review', 'Medication changed after confirmation; review it again.');
      }
      for (const field of med.uncertain_fields) {
        if (med[field] && !metadata.patientConfirmedFields?.includes(field)) {
          add(index, field, 'uncertain_field', 'Explicitly check this nonempty uncertain field.');
        }
      }
    }
    if (med.conflicts.length) add(index, null, 'unresolved_conflicts', 'Resolve conflicting values before sharing.');
  }
  return issues;
}

/** Only fields accepted by backend v2 SharedMedication leave the client. */
export function createSharePayload(medications, options) {
  const issues = getShareIssues(medications, options);
  if (issues.length) throw new ShareValidationError(issues);
  return {
    medications: medications.map(current => {
      const med = normalizeMedication(current);
      return {
        id: med.id,
        kind: med.kind,
        ...Object.fromEntries(MEDICATION_FIELDS.map(field => [field, med[field] || null])),
        source: med.source,
        sources: med.sources,
        ...(med.note_style !== undefined ? { note_style: med.note_style } : {}),
      };
    }),
  };
}
