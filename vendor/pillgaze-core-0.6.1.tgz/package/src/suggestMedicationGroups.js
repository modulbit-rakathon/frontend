import { alternativeNames, suggestMedicationCandidates } from './suggestMedicationCandidates.js';
import { matchMedication } from './matchMedication.js';
import { normalizeText, nameKeys } from './normalize.js';
import { normalizeMedication } from './medicationModel.js';

function ingredientLabels(candidate) {
  const text = candidate.ingredientText ?? '';
  // Do not split combination substances into apparent single-drug alternatives.
  if (/[;/+]/.test(text) || candidate.ingredientCodes?.length > 1) return [];
  return alternativeNames(text).map(normalizeText);
}

/** Adjacent missing-strength lines may be aliases, but remain separate observations. */
export function suggestMedicationGroups(medications, { catalog } = {}) {
  if (!Array.isArray(medications) || !Array.isArray(catalog)) throw new TypeError('Provide medications and catalog arrays.');
  const meds = Array.from(medications, med => normalizeMedication(med));
  const ids = meds.map((med, index) => medications[index]._core?.observationId ?? med.id);
  if (new Set(ids).size !== ids.length) throw new TypeError('Observation IDs must be unique.');
  const suggestions = [];
  for (let index = 1; index < meds.length; index++) {
    const first = meds[index - 1];
    const second = meds[index];
    if (first.kind !== 'drug' || second.kind !== 'drug' || !first.name || !second.name
        || !first.strength || second.strength || first.source !== 'note' || second.source !== 'note') continue;
    const firstCandidates = matchMedication(first, catalog).candidates;
    const labels = nameKeys(second.name, second.strength);
    const ingredientMatch = firstCandidates.some(candidate =>
      ingredientLabels(candidate).some(label => labels.includes(label)));
    const sharedName = nameKeys(first.name, first.strength).some(name => labels.includes(name));
    let candidateIds = [];
    if (!ingredientMatch && !sharedName) {
      const alternatives = suggestMedicationCandidates(second, catalog, { limit: 100 }).suggestions
        .filter(item => item.editDistance === 0).map(item => item.candidate);
      candidateIds = firstCandidates.filter(candidate => candidate.ingredientCodes?.length
        && alternatives.some(other => other.ingredientCodes?.length === candidate.ingredientCodes.length
          && [...other.ingredientCodes].sort().join('|') === [...candidate.ingredientCodes].sort().join('|')))
        .map(candidate => candidate.id);
    }
    if (ingredientMatch || sharedName || candidateIds.length) suggestions.push({
      observationIds: [ids[index - 1], ids[index]], medicationIds: [first.id, second.id],
      reason: sharedName ? 'repeated_name_without_strength' : 'possible_ingredient_or_brand_alias',
      requiresConfirmation: true,
    });
  }
  return suggestions;
}
