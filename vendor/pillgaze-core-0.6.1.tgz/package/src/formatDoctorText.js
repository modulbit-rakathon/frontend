function fieldText(field) {
  if (field.status === 'conflict') {
    const values = [...new Set(field.alternatives.filter(a => a.weight > 0).map(a => a.value))];
    return `[K OVĚŘENÍ: ${values.join(' / ')}]`;
  }
  return field.value ?? '[nezjištěno]';
}

/** Draft for copying to the doctor's workspace. Conflicts remain visible. */
export function formatDoctorText(medications) {
  if (!Array.isArray(medications)) throw new TypeError('Medications must be an array.');
  const lines = medications.map(({ fields }) =>
    `${fieldText(fields.name)}; síla: ${fieldText(fields.strength)}; užívání: ${fieldText(fields.dosage)}`);
  return ['Návrh přehledu medikace ke kontrole lékařem', ...lines].join('\n');
}
