import { finalizeMedication } from './frontendAdapter.js';
import { medicationText } from './medicationModel.js';

/** An explicit selection proposes catalogue facts; the patient still reviews them. */
export function selectMedicationCandidate(current, candidateId, { catalog } = {}) {
  if (current?._core?.version !== 1 || current.kind !== 'drug') {
    throw new TypeError('Select a candidate for a prepared drug, not a regimen.');
  }
  if (!Array.isArray(catalog) || typeof candidateId !== 'string' || !candidateId) {
    throw new TypeError('A catalog and candidate ID are required.');
  }
  const candidates = catalog.filter(item => item.id === candidateId);
  if (candidates.length !== 1) throw new TypeError('Candidate ID must identify exactly one catalog record.');
  const candidate = candidates[0];
  const values = { name: medicationText(candidate.name, 'candidate.name'), strength: medicationText(candidate.strength, 'candidate.strength') };
  if (!values.name) throw new TypeError('Catalog candidate name is required.');
  if (candidate.form != null) values.form = medicationText(candidate.form, 'candidate.form');
  if (candidate.ingredientText != null) values.active_substance = medicationText(candidate.ingredientText, 'candidate.ingredientText');
  for (const field of ['form', 'active_substance']) {
    const origin = current._core.fieldOrigins?.[field];
    if (!Object.hasOwn(values, field) && origin?.kind === 'catalog' && origin.candidateId !== candidateId) values[field] = '';
  }
  const baseline = structuredClone(current);
  delete baseline._core.catalogSelection;
  const selected = finalizeMedication(baseline, values, { catalog });
  const metadata = selected._core;
  metadata.catalogHistory ??= [];
  if (current._core.catalogSelection) metadata.catalogHistory.push(structuredClone(current._core.catalogSelection));
  metadata.catalogSelection = {
    active: true, candidateId, source: candidate.source ?? 'catalog',
    values: structuredClone(values), actor: 'patient_selection',
  };
  metadata.fieldOrigins ??= {};
  for (const [field, value] of Object.entries(values)) {
    metadata.fieldOrigins[field] = { kind: value ? 'catalog' : 'catalog_missing', candidateId, source: candidate.source ?? 'catalog', value };
  }
  const intrinsic = ['name', 'strength', 'form', 'active_substance'];
  metadata.patientConfirmedFields = metadata.patientConfirmedFields.filter(field => !intrinsic.includes(field));
  metadata.patientReviewed = false;
  delete metadata.reviewedValues;
  selected.uncertain_fields = [...new Set([...selected.uncertain_fields, ...intrinsic])];
  return selected;
}
