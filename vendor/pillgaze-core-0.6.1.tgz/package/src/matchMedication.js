import { nameKeys, strengthKey, hasUnitlessStrength } from './normalize.js';

/** Candidate lookup, not a prescription or a substitution recommendation. */
export function matchMedication(input, catalog) {
  if (!input || typeof input.name !== 'string' || !input.name.trim()) {
    throw new TypeError('Medication name must be a non-empty string.');
  }
  if (!Array.isArray(catalog)) throw new TypeError('Catalog must be an array.');
  if (input.strength != null && typeof input.strength !== 'string') {
    throw new TypeError('Strength must be a string or null.');
  }
  const names = nameKeys(input.name, input.strength);
  const named = catalog.filter(item => nameKeys(item.name, item.strength)
    .some(name => names.includes(name))).map(item => structuredClone(item));
  if (!named.length) return { status: 'not_found', reason: 'unknown_name', candidates: [] };

  const suppliedStrength = typeof input.strength === 'string' && input.strength.trim() !== '';
  if (suppliedStrength && hasUnitlessStrength(input.strength)) {
    return { status: 'needs_review', reason: 'missing_strength_unit', candidates: named };
  }
  const candidates = suppliedStrength
    ? named.filter(item => strengthKey(item.strength) === strengthKey(input.strength))
    : named;
  if (!candidates.length) {
    return { status: 'needs_review', reason: 'strength_mismatch', candidates: named };
  }
  if (candidates.length !== 1) {
    return { status: 'needs_review', reason: 'multiple_candidates', candidates };
  }
  return {
    status: suppliedStrength && !input.uncertain_fields?.includes('name') ? 'matched' : 'needs_review',
    reason: !suppliedStrength ? 'missing_strength' : input.uncertain_fields?.includes('name')
      ? 'uncertain_name' : 'exact_name_and_strength',
    candidates,
  };
}
