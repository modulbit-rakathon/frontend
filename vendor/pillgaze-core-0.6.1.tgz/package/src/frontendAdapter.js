import { matchMedication } from './matchMedication.js';
import { mapBackendResponse } from './backendAdapter.js';
import { suggestMedicationCandidates } from './suggestMedicationCandidates.js';
import {
  MEDICATION_FIELDS, isObject, medicationFields, normalizeMedication,
} from './medicationModel.js';

function lookup(values, catalog) {
  if (values.kind === 'regimen') {
    return { status: 'needs_review', reason: 'regimen_requires_resolution', candidates: [] };
  }
  return values.name
    ? matchMedication(values, catalog)
    : { status: 'not_found', reason: 'missing_name', candidates: [] };
}

function addUncertainty(med, match, uncertain) {
  const fields = med.kind === 'regimen' ? ['name'] : MEDICATION_FIELDS;
  for (const field of fields) if (!med[field]) uncertain.add(field);
  if (med.kind === 'regimen') return;
  if (match.status === 'not_found') uncertain.add('name');
  if (match.status === 'needs_review') {
    uncertain.add(match.reason === 'uncertain_name' ? 'name'
      : match.reason === 'multiple_candidates' && med.strength ? 'form' : 'strength');
  }
}

function suggestions(values, match, catalog) {
  return values.kind === 'drug' && values.name && match.status !== 'matched'
    ? suggestMedicationCandidates(values, catalog) : null;
}

/** Preserve the interface consumed by Scan.jsx and MedForm.jsx. */
export function prepareAnalysisResult(response, { catalog, analysisId } = {}) {
  if (!Array.isArray(catalog)) throw new TypeError('catalog must be an array.');
  if (typeof analysisId !== 'string' || !analysisId.trim()) throw new TypeError('analysisId is required.');
  response = mapBackendResponse(response);
  if (!Array.isArray(response.medications)
      || !Array.isArray(response.unreadable_items)
      || [...response.unreadable_items].some(v => typeof v !== 'string')) {
    throw new TypeError('Expected { medications: Array, unreadable_items: string[] }.');
  }
  if (response.unreadable_count !== undefined
      && (!Number.isSafeInteger(response.unreadable_count) || response.unreadable_count < 0)) {
    throw new TypeError('unreadable_count must be a nonnegative integer.');
  }
  return {
    ...(response.unreadable_count !== undefined ? { unreadable_count: response.unreadable_count } : {}),
    medications: Array.from(response.medications, (med, index) => {
      const observationId = `${analysisId}:${index}`;
      const values = normalizeMedication(med, { fallbackId: observationId, legacy: true });
      const reported = values.uncertain_fields;
      const uncertain = new Set([...reported, ...values.conflicts.map(conflict => conflict.field)]);
      // Printed box instructions are not a patient's confirmed regimen.
      if (values.kind === 'drug' && med.source === 'box') {
        uncertain.add('frequency');
        uncertain.add('amount');
      }
      const match = lookup(values, catalog);
      addUncertainty(values, match, uncertain);
      return {
        ...values, uncertain_fields: [...uncertain],
        _core: {
          version: 1, observationId,
          original: {
            ...Object.fromEntries(MEDICATION_FIELDS.map(field => [field, med[field] ?? null])),
            source: med.source,
            ...Object.fromEntries(['id', 'kind', 'note_style', 'sources', 'conflicts']
              .filter(field => Object.hasOwn(med, field)).map(field => [field, structuredClone(med[field])])),
          },
          originalUncertainFields: reported, match, suggestions: suggestions(values, match, catalog),
          // Patient confirmation is distinct from a clinical review.
          patientConfirmedFields: [], patientReviewed: false, edits: [], resolvedConflicts: [],
        },
      };
    }),
    unreadable_items: [...response.unreadable_items],
  };
}

export function prepareMedications(medications, options) {
  return prepareAnalysisResult({ medications, unreadable_items: [] }, options).medications;
}

/** Save current form values while keeping OCR evidence and unresolved flags. */
export function finalizeMedication(current, values, { catalog, confirmedFields = [] } = {}) {
  if (!isObject(current) || current._core?.version !== 1 || !isObject(values)) {
    throw new TypeError('Use a prepared medication and form values.');
  }
  if (!Array.isArray(catalog)) throw new TypeError('catalog must be an array.');
  const confirmed = medicationFields(confirmedFields, 'confirmedFields');
  const baseline = normalizeMedication({ ...current._core.original, ...current }, {
    fallbackId: current._core.observationId, legacy: true,
  });
  const next = normalizeMedication({
    ...baseline,
    ...Object.fromEntries(MEDICATION_FIELDS.filter(field => Object.hasOwn(values, field))
      .map(field => [field, values[field]])),
  });
  if (!next.name) throw new TypeError('Medication name is required to save.');
  const metadata = structuredClone(current._core);
  const selection = metadata.catalogSelection;
  if (selection && ['name', 'strength', 'form'].some(field => next[field] !== baseline[field])) {
    selection.active = false;
    for (const field of ['active_substance', 'form']) {
      const origin = metadata.fieldOrigins?.[field];
      if (origin?.kind === 'catalog' && next[field] === origin.value && !confirmed.includes(field)) next[field] = '';
    }
  }
  const changed = MEDICATION_FIELDS.filter(field => next[field] !== baseline[field]);
  const identityChanged = ['name', 'strength', 'form'].some(field => changed.includes(field));
  for (const field of changed) {
    metadata.edits.push({ field, previous: baseline[field], value: next[field], actor: 'patient' });
    if (metadata.fieldOrigins?.[field]) metadata.fieldOrigins[field] = { kind: 'patient', value: next[field] };
  }
  const confirmations = new Set(identityChanged ? []
    : metadata.patientConfirmedFields.filter(f => !changed.includes(f)));
  for (const f of confirmed) if (next[f]) confirmations.add(f);
  metadata.patientConfirmedFields = [...confirmations];
  metadata.patientReviewed = true;
  metadata.reviewedValues = Object.fromEntries(MEDICATION_FIELDS.map(field => [field, next[field]]));
  metadata.reviewedKind = next.kind;
  metadata.reviewedSource = next.source;
  metadata.reviewedProvenance = { sources: [...next.sources], note_style: next.note_style ?? null };
  next.conflicts = baseline.conflicts.filter(conflict => {
    if (!confirmed.includes(conflict.field) || !next[conflict.field]) return true;
    metadata.resolvedConflicts ??= [];
    metadata.resolvedConflicts.push({ ...structuredClone(conflict), value: next[conflict.field], actor: 'patient' });
    return false;
  });
  const uncertain = new Set(medicationFields(current.uncertain_fields ?? [], 'uncertain_fields'));
  for (const f of changed) uncertain.add(f);
  if (identityChanged) for (const f of MEDICATION_FIELDS) if (next[f]) uncertain.add(f);
  for (const f of confirmations) uncertain.delete(f);
  for (const conflict of next.conflicts) uncertain.add(conflict.field);
  metadata.match = lookup({ ...next, uncertain_fields: [...uncertain] }, catalog);
  metadata.suggestions = suggestions(next, metadata.match, catalog);
  // Confirmation cannot make an unknown/ambiguous catalogue match authoritative.
  addUncertainty(next, metadata.match, uncertain);
  return { ...next, uncertain_fields: [...uncertain], _core: metadata };
}

/**
 * Wrap the team's existing async analyzePhoto. HTTP endpoint/auth/upload stay
 * with the backend client. mapResponse is the only backend-specific boundary.
 */
export function createAnalyzePhoto({ analyze, catalog, mapResponse = mapBackendResponse,
  createAnalysisId = () => globalThis.crypto.randomUUID() } = {}) {
  if (typeof analyze !== 'function' || typeof mapResponse !== 'function'
      || typeof createAnalysisId !== 'function' || !Array.isArray(catalog)) {
    throw new TypeError('Expected analyze, catalog and optional mapResponse/createAnalysisId functions.');
  }
  return async (...args) => {
    const analysisId = createAnalysisId();
    const response = await analyze(...args);
    return prepareAnalysisResult(await mapResponse(response), { catalog, analysisId });
  };
}
