/** Map the team's OCR API, where unreadable_items is a count, to the UI contract. */
export function mapBackendResponse(response) {
  if (response === null || typeof response !== 'object' || Array.isArray(response)) {
    throw new TypeError('Expected an OCR response object.');
  }
  if (Array.isArray(response.unreadable_items)) {
    const count = response.unreadable_count === undefined
      ? response.unreadable_items.length : response.unreadable_count;
    if (!Number.isSafeInteger(count) || count < 0 || (response.unreadable_items.length > 0 && count === 0)) {
      throw new TypeError('unreadable_count must be nonnegative and cannot hide unreadable messages.');
    }
    return { ...response, unreadable_count: count };
  }
  const count = response.unreadable_items;
  if (!Number.isSafeInteger(count) || count < 0) {
    throw new TypeError('unreadable_items must be a nonnegative integer or a string array.');
  }
  return {
    ...response,
    unreadable_count: count,
    unreadable_items: count === 0 ? [] : [`Počet nepřečtených položek: ${count}. Doplňte je ručně.`],
  };
}
