import { normalizeText, nameKeys, strengthKey } from './normalize.js';
import { isObject } from './medicationModel.js';

const modifiers = name => [...normalizeText(name).matchAll(/\b(?:retard|xr|sr|cr|mr|prolong)\b/g)]
  .map(match => match[0]).sort().join('|');

export function alternativeNames(name) {
  const parts = [name];
  const brackets = [...name.matchAll(/\(([^()]*)\)/g)].map(match => match[1].trim());
  if (brackets.length && brackets.every(part => !modifiers(part) && /[a-z]/i.test(part))) {
    parts.push(name.replace(/\([^()]*\)/g, ' ').trim(), ...brackets);
  }
  for (const part of [...parts]) {
    if (part.includes('/')) parts.push(...part.split('/').map(value => value.trim()));
  }
  return [...new Set(parts.filter(part => /[a-z]/i.test(part) && part.trim()).map(part => part.trim()))];
}

function editDistance(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  let previous = Array.from({ length: b.length + 1 }, (_, index) => index);
  let beforePrevious;
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    for (let j = 1; j <= b.length; j++) {
      row[j] = Math.min(previous[j] + 1, row[j - 1] + 1, previous[j - 1] + Number(a[i - 1] !== b[j - 1]));
      if (beforePrevious && i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
        row[j] = Math.min(row[j], beforePrevious[j - 2] + 1);
      }
    }
    if (Math.min(...row) > max) return max + 1;
    beforePrevious = previous;
    previous = row;
  }
  return previous[b.length];
}

/** Bounded spelling/alternative suggestions, never a confirmed identity or substitution. */
export function suggestMedicationCandidates(input, catalog, { limit = 20 } = {}) {
  if (!isObject(input) || typeof input.name !== 'string' || !input.name.trim()
      || (input.strength != null && typeof input.strength !== 'string')) {
    throw new TypeError('Suggestions require a name and optional text strength.');
  }
  if (!Array.isArray(catalog)) throw new TypeError('Catalog must be an array.');
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new TypeError('limit must be between 1 and 100.');
  if (input.kind === 'regimen') {
    return { status: 'needs_review', reason: 'regimen_requires_resolution', candidates: [], suggestions: [], total: 0, truncated: false };
  }
  const parts = alternativeNames(input.name).flatMap(part =>
    nameKeys(part, input.strength).map(key => ({ key, part })));
  const ranked = [];
  for (const candidate of catalog) {
    let best;
    for (const { key, part } of parts) {
      const max = key.length >= 8 ? 2 : key.length >= 5 ? 1 : 0;
      for (const candidateKey of nameKeys(candidate.name, candidate.strength)) {
        if (modifiers(key) !== modifiers(candidateKey)) continue;
        const prefix = candidateKey.split(' ').slice(0, key.split(' ').length).join(' ');
        const distance = Math.min(editDistance(key, candidateKey, max), editDistance(key, prefix, max));
        if (distance > max) continue;
        const reason = distance ? 'spelling' : candidateKey !== key ? 'name_prefix'
          : part !== input.name ? 'alternative_name' : 'exact_name';
        const exact = reason === 'exact_name' ? 0 : reason === 'alternative_name' ? 1 : reason === 'name_prefix' ? 2 : 3;
        const strengthMatches = input.strength ? strengthKey(input.strength) === strengthKey(candidate.strength) : null;
        const suggestion = { candidate, matchedName: part, reason, editDistance: distance, strengthMatches, rank: exact };
        if (!best || exact < best.rank || (exact === best.rank && distance < best.editDistance)) best = suggestion;
      }
    }
    if (best) ranked.push(best);
  }
  ranked.sort((a, b) => a.rank - b.rank || a.editDistance - b.editDistance
    || Number(b.strengthMatches === true) - Number(a.strengthMatches === true)
    || a.candidate.name.localeCompare(b.candidate.name, 'cs')
    || a.candidate.strength.localeCompare(b.candidate.strength, 'cs', { numeric: true })
    || a.candidate.id.localeCompare(b.candidate.id));
  const suggestions = ranked.slice(0, limit).map(({ rank, ...suggestion }) => ({
    ...suggestion, candidate: structuredClone(suggestion.candidate),
  }));
  return {
    status: ranked.length ? 'needs_review' : 'not_found',
    reason: ranked.length ? 'candidate_suggestions' : 'unknown_name',
    candidates: suggestions.map(item => item.candidate), suggestions,
    total: ranked.length, truncated: ranked.length > limit,
  };
}
